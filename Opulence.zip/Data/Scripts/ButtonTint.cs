using System.Collections.Generic;
using BellyRub;

namespace CSharpAssembly
{
    public class ButtonTint : ScriptController
	{
		// gets all buttons in the scene and when the button is hovered it tints it. it can also outline the button if that functionallity is added in later
		List<Sprite_Button> m_Buttons = new List<Sprite_Button>();

		void Start()
		{
			// gets all buttons in the scene
			List<Entity> m_UiEntities = Scene.FindEntitiesWithLayer(Layer.UI);

			foreach (Entity entity in m_UiEntities)
			{
				m_Buttons.Add(entity.GetScript<Sprite_Button>());
			}
		}

		void Update()
		{
			// when the button is hovered it tints it
			foreach (Sprite_Button button in m_Buttons)
			{
				if (button.IsHovered())
				{
					button.entity.material.tint = new Colour4 (0f, 0f, 0f, 0.5f);
				}
				else
				{
					button.entity.material.tint = Colour4.White;
				}
			}
		}
	}
}
using System;
using System.Collections.Generic;
using System.IO;
using BellyRub;

namespace CSharpAssembly
{
	public class HotKeyHandler : ScriptController
	{
		string HotKeyFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Unbox Games", "Opulence", "HotKeys.txt");
		
		private Dictionary<string, KeyCode> HotKeys = new Dictionary<string, KeyCode>();

		void Start()
		{
			// Set default hot keys
			HotKeys.Add("MainMenu", KeyCode.Escape);

			HotKeys.Add("Collect", KeyCode.Q);
			HotKeys.Add("Refine",  KeyCode.W);
			HotKeys.Add("Craft",   KeyCode.E);
			HotKeys.Add("Upgrade", KeyCode.R);
			HotKeys.Add("Sell",    KeyCode.T);

			ReadHotKeyFile();
		}

		void Exit()
		{
			WriteHotKeyFile();
		}

		void Update()
		{
			if (Input.IsKeyPressed(KeyCode.Insert)) { WriteHotKeyFile();}

			if (Input.IsKeyPressed(HotKeys["MainMenu"])) { Scene.SetScene("MainMenu"); }

			if (Scene.GetName() != "MainMenu")
			{
				if (Input.IsKeyPressed(HotKeys["Collect"])) { Scene.SetScene("GenericCollect"); }
				if (Input.IsKeyPressed(HotKeys["Refine"]))  { Scene.SetScene("GenericRefine"); }
				if (Input.IsKeyPressed(HotKeys["Craft"]))   { Scene.SetScene("GenericCraft"); }
				if (Input.IsKeyPressed(HotKeys["Upgrade"])) { Scene.SetScene("GenericUpgrade"); }
				if (Input.IsKeyPressed(HotKeys["Sell"]))    { Scene.SetScene("GenericSell"); }
			}
		}

		void ReadHotKeyFile()
		{
			// Magic
			try
	        {
	            if (File.Exists(HotKeyFile))
	            {
	                string[] lines = File.ReadAllLines(HotKeyFile);
					foreach (string line in lines)
					{
						string[] parts = line.Split('=');
						if (parts.Length == 2)
						{
							string key = parts[0].Trim();
							if (Enum.TryParse(parts[1].Trim(), out KeyCode value))
							{
								HotKeys[key] = value;
							}
						}
	                }
	            }
	        }
	        catch (Exception exception) { Debug.LogError("Error reading hot key file" + exception.Message); }
		}

		void WriteHotKeyFile()
		{
			// More magic
			try
			{
				Directory.CreateDirectory(Path.GetDirectoryName(HotKeyFile));

				string[] lines = new string[HotKeys.Count];
				int i = 0;
				foreach (KeyValuePair<string, KeyCode> pair in HotKeys)
				{
					lines[i] = pair.Key + "=" + pair.Value.ToString();
					i++;
				}
				File.WriteAllLines(HotKeyFile, lines);
			}
			catch (Exception exception) { Debug.LogError("Error writing hot key file" + exception.Message);}
		}
	}
}
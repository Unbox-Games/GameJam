using BellyRub;
using System;
using System.Collections.Generic;

namespace CSharpAssembly
{
	public class Sprite_Button: ScriptController
	{
		public Sprite m_Button        = Sprite.Invalid;
		public Sprite m_ButtonHovered = Sprite.Invalid;
		public Sprite m_ButtonPressed = Sprite.Invalid;

		private SpriteComponent m_SpriteComponent     = null;
		private AudioPlayerComponent m_AudioComponent = null;

		private bool m_Pressed = false;
		private bool m_Hovered = false;

		public bool IsPressed() { return m_Pressed; }
		public bool IsHovered() { return m_Hovered; }

		void _SetSprite(Sprite sprite)
		{
			if (m_SpriteComponent == null)
				return;

			m_SpriteComponent.sprite = sprite;
		}

		void Start()
		{
			m_AudioComponent  = GetComponent<AudioPlayerComponent>();
			m_SpriteComponent = GetComponent<SpriteComponent>();
			if (m_SpriteComponent == null)
				Debug.LogWarning($"Button {entity.name} Doesn't have a Sprite Component!");
		}

		void Update()
		{
			if (m_Hovered && !m_Pressed)
				_SetSprite(m_ButtonHovered);

			else if (!m_Hovered && !m_Pressed)
				_SetSprite(m_Button);

			if (m_Pressed && !m_Hovered)
				m_Pressed = false;

			m_Hovered = false;
		}

		void OnClick(MouseCode mouse)
		{
			m_AudioComponent.Play();
			m_Pressed = true;
			_SetSprite(m_ButtonPressed);
		}

		void OnHovered()
		{
			m_Hovered = true;
		}

		// A dictionary that stores the actions for each button in every scene
		// The outer dictionary is keyed by the name of the scene, and the inner dictionaries are keyed by the name of the button
		private Dictionary<string, Dictionary<string, Action>> m_ButtonActions = new Dictionary<string, Dictionary<string, Action>>()
		{
		    {"MainMenu", new Dictionary<string, Action>()
		        {
		            {"Play", 	 () => Scene.SetScene("Intermediate")},
                    {"Tutorial", () => Scene.SetScene("Tutorial")},
                    {"Options",  () => Scene.SetScene("GenericOptions")},
                    {"Credits",  () => Scene.SetScene("Credits")},
                    {"Language", () => Scene.SetScene("LanguageSelect")},
                    {"Exit", 	 () => Window.Close()},
                    //{"Discord",  () => System.Diagnostics.Process.Start("https://discord.com")},
                    //{"Reddit", 	 () => System.Diagnostics.Process.Start("https://reddit.com")},
                    //{"Steam", 	 () => System.Diagnostics.Process.Start("https://store.steampowered.com")},
                    //{"Wiki", 	 () => System.Diagnostics.Process.Start("https://fandom.com")},
                }
            },
            {"Intermediate", new Dictionary<string, Action>()
                {
                    {"Collect",    () => Scene.SetScene("GenericCollect")},
                    {"Refine", 	   () => Scene.SetScene("GenericRefine")},
                    {"Craft", 	   () => Scene.SetScene("GenericCraft")},
                    {"Upgrade",    () => Scene.SetScene("GenericUpgrade")},
                    {"ArrowRight", () => Scene.SetScene("GenericSell")},
                }
            },
			{"Credits", new Dictionary<string, Action>()
				{
					{"Back", () => Scene.SetScene("MainMenu")}
				}			
			},
        };
		
		void OnReleased(MouseCode mouse)
		{
		    m_Pressed = false;
		    // Check if the current scene has a dictionary of actions
		    if (m_ButtonActions.TryGetValue(Scene.GetName(), out Dictionary<string, Action> sceneActions))
		    {
		        // Check if the button has an action associated with it
		        if (sceneActions.TryGetValue(entity.name, out Action action))
		        {
		            // Perform the action
		            action();
		        }
		    }
		}

		//void OnReleased(MouseCode mouse)
		//{
		//	m_Pressed = false;
		//	if (Scene.GetName().Equals("MainMenu"))
		//	{
		//		if (entity.name == "Play")     { Scene.SetScene("Intermediate"); }
		//		if (entity.name == "Tutorial") { Scene.SetScene("Tutorial"); }
		//		if (entity.name == "Options")  { Scene.SetScene("GenericOptions"); }
		//		if (entity.name == "Credits")  { Scene.SetScene("Credits"); }
		//
		//		// Open a link
		//		if (entity.name == "Discord") {} // { System.Diagnostics.Process.Start("https://discord.com"); }
		//		if (entity.name == "Reddit")  {} // { System.Diagnostics.Process.Start("https://reddit.com"); }
		//		if (entity.name == "Steam")   {} // { System.Diagnostics.Process.Start("https://store.steampowered.com"); }
		//		if (entity.name == "Wiki")    {} // { System.Diagnostics.Process.Start("https://fandom.com"); }
		//
		//		if (entity.name == "Exit") 	   { Window.Close(); }
		//		if (entity.name == "Language") { Scene.SetScene("LanguageSelect"); }
		//	}
		//
		//	if (Scene.GetName().Equals("Intermediate"))
		//	{
		//		if (entity.name == "Collect")     { Scene.SetScene("GenericCollect"); }
		//		if (entity.name == "Refine")      { Scene.SetScene("GenericRefine"); }
		//		if (entity.name == "Craft")       { Scene.SetScene("GenericCraft"); }
		//		if (entity.name == "Upgrade")     { Scene.SetScene("GenericUpgrade"); }
		//		if (entity.name == "Arrow Right") { Scene.SetScene("GenericSell"); }
		//	}
		//}
	}
}
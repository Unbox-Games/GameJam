using System;
using System.Collections.Generic;
using BellyRub;

namespace CSharpAssembly
{
	public static class JukeBox
	{
		public static AudioSource m_AudioSource = AudioSource.Invalid;
		public static bool StartedPlaying       = false;
		public static UInt32 m_Handle           = 0;
		static List<String> m_Songs             = new List<String>();
		static int m_NextSongIndex              = 0;

		public static bool m_Started 			= false;

		static void AddSongs()
		{
			m_Songs.Add("Americano"			);  // Track 1		ID: 0
			m_Songs.Add("Apple Pie"			);  // Track 2		ID: 1
			m_Songs.Add("Bagles"			);	// Track 3		ID: 2
			m_Songs.Add("Cafe Frappe"		);	// Track 4		ID: 3
			m_Songs.Add("Cappuccino"		);	// Track 5		ID: 4
			m_Songs.Add("Caramel Macchiato"	);	// Track 6		ID: 5
			m_Songs.Add("Carrot Cake"		);	// Track 7		ID: 6
			m_Songs.Add("Champagne"			);	// Track 8		ID: 7
			m_Songs.Add("Chantilly"			);  // Track 9		ID: 8
			m_Songs.Add("Chocolate"			);  // Track 10		ID: 9
			m_Songs.Add("Coffee Liqueur"	);	// Track 11		ID: 10
			m_Songs.Add("Cookie"			);	// Track 12		ID: 11
			m_Songs.Add("Creamer"			);  // Track 13		ID: 12
			m_Songs.Add("Croissant"			);	// Track 14		ID: 13
			m_Songs.Add("Decaffeinato"		);	// Track 15		ID: 14
			m_Songs.Add("Donut"				);	// Track 16		ID: 15
			m_Songs.Add("Latte Coco"		);	// Track 17		ID: 16
			m_Songs.Add("Latte Macchiato"	);	// Track 18		ID: 17
			m_Songs.Add("Metropolitan"		);	// Track 19		ID: 18
			m_Songs.Add("Milkshake"			);  // Track 20		ID: 19
			m_Songs.Add("Mocaccino"			);	// Track 21		ID: 20
			m_Songs.Add("Sofa"				);	// Track 22		ID: 21
			m_Songs.Add("Vanila Shake"		);  // Track 23		ID: 22
		}

		public static void Start()
		{
			if(m_Started)
				return;
			
			AddSongs();

			m_Started = true;
		}

		static void SelectSong()
		{
			AudioSource audio = Assets.GetAudioSource(m_Songs[m_NextSongIndex]);
			m_AudioSource = audio;
		}

		public static void Play()
		{
			SelectSong();

			m_Handle = Audio.PlayAudioSource(m_AudioSource);

			// Loop Handling.
			m_NextSongIndex++;
			if(m_NextSongIndex >= m_Songs.Count)
				m_NextSongIndex = 0;
				
			StartedPlaying = true;
		}

		public static void Update()
		{
		 	if(m_Handle != 0 && !Audio.IsAudioSourcePlaying(m_Handle))
		 		Play();
		}
	}
	
	public class JukeBoxHandler : ScriptController
	{
		void Start()
		{
			JukeBox.Start();

			if(JukeBox.m_Started && !JukeBox.StartedPlaying)
			{
				JukeBox.Play();
			}
		}

		void Update()
		{
			JukeBox.Update();
		}
	}
}
using System;
using System.Collections.Generic;
using System.IO;
using BellyRub;

namespace CSharpAssembly
{
    public class SaveFileHandler : ScriptController
    {
		// On exit, this class will get the values of each of the items that a player currently has and store them to a save file.
		// On Load, this class will load the save file and set the values of each of the items that the player currently has.
        string SaveFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Unbox Games", "Opulence", "Save_File.txt");

        void Start()
        {
            //InventoryManager.Start();
            ReadSave();
        }

		void Exit()
		{
			WriteSave();
		}

        void Update()
        {
            if (Input.IsKeyPressed(KeyCode.Home)) { WriteSave(); }
            if (Input.IsKeyPressed(KeyCode.End))  { InventoryManager.Inventory["Oak_Log"] += 1; }
        }
        
        private void ReadSave()
        {
            try
            {
                if (File.Exists(SaveFile))
                {
                    string[] lines = File.ReadAllLines(SaveFile);
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split('=');
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim();
                            if (uint.TryParse(parts[1].Trim(), out uint value))
                            {
                                InventoryManager.Inventory[key] = value;
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
				Debug.LogError("Error reading save file" + exception.Message);
            }
        }

        private void WriteSave()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SaveFile));

                string[] lines = new string[InventoryManager.Inventory.Count];
                int i = 0;
                foreach (KeyValuePair<string, uint> pair in InventoryManager.Inventory)
                {
                    lines[i] = pair.Key + "=" + pair.Value.ToString();
                    i++;
                }
                File.WriteAllLines(SaveFile, lines);
            }
            catch (Exception exception)
            {
				Debug.LogError("Error writing save file: " + exception.Message);
            }
        }
    }
}


using BellyRub;

namespace CSharpAssembly
{
    public class CollectManager : ScriptController
	{
		void Start()
		{
			
		}

		void Update()
		{
			
		}
	}
}